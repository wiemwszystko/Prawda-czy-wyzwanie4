import React, { useState } from 'react';

const pytaniaStartowe = [
  'Jaka była Twoja pierwsza myśl, kiedy tu weszliśmy?',
  'Co najbardziej lubisz w swojej drugiej połówce?',
  'Czy kiedykolwiek miałeś/aś zakazany romans?',
];

const zadaniaStartowe = [
  'Daj całusa osobie po Twojej lewej.',
  'Zatańcz krótki taniec erotyczny.',
  'Wypowiedz jedno z najskrytszych marzeń seksualnych.',
];

export default function App() {
  const [gracze, setGracze] = useState([]);
  const [nowyGracz, setNowyGracz] = useState('');
  const [etap, setEtap] = useState('wpisywanie');
  const [wiadomosc, setWiadomosc] = useState('');

  const dodajGracza = () => {
    if (nowyGracz.trim()) {
      setGracze([...gracze, nowyGracz.trim()]);
      setNowyGracz('');
    }
  };

  const rozpocznijGre = () => {
    setEtap('gra');
    losujPytanieLubZadanie();
  };

  const losujPytanieLubZadanie = () => {
    const los = Math.random();
    const gracz = gracze[Math.floor(Math.random() * gracze.length)];

    if (los < 0.5) {
      const pytanie = pytaniaStartowe[Math.floor(Math.random() * pytaniaStartowe.length)];
      setWiadomosc(`${gracz}, pytanie: ${pytanie}`);
      setEtap('pytanie');
    } else {
      const zadanie = zadaniaStartowe[Math.floor(Math.random() * zadaniaStartowe.length)];
      setWiadomosc(`${gracz}, zadanie: ${zadanie}`);
      setEtap('zadanie');
    }
  };

  return (
    <div style={{ maxWidth: 600, margin: 'auto', padding: 20, fontFamily: 'sans-serif' }}>
      <h1 style={{ textAlign: 'center' }}>Prawda czy Wyzwanie</h1>

      {etap === 'wpisywanie' && (
        <div>
          <input
            type="text"
            placeholder="Wpisz imię gracza"
            value={nowyGracz}
            onChange={(e) => setNowyGracz(e.target.value)}
            style={{ width: '100%', padding: 8, marginBottom: 10 }}
          />
          <button onClick={dodajGracza} style={{ padding: 10, marginBottom: 20 }}>Dodaj gracza</button>
          <ul>
            {gracze.map((g, i) => (
              <li key={i}>{g}</li>
            ))}
          </ul>
          {gracze.length >= 2 && (
            <button onClick={rozpocznijGre} style={{ padding: 10, backgroundColor: '#28a745', color: 'white' }}>Rozpocznij grę</button>
          )}
        </div>
      )}

      {(etap === 'pytanie' || etap === 'zadanie') && (
        <div style={{ marginTop: 30, textAlign: 'center' }}>
          <p style={{ fontSize: 20 }}>{wiadomosc}</p>
          <button onClick={losujPytanieLubZadanie} style={{ marginTop: 20, padding: 10 }}>Następne</button>
        </div>
      )}
    </div>
  );
}